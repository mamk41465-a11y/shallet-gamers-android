SHALLET GAMERS - Android starter project

هذا مشروع أندرويد أولي يغلّف واجهة SHALLET GAMERS الحالية داخل تطبيق Android WebView.
ليس APK جاهزاً بعد. كما أن واجهة الغرف الموجودة حالياً تجريبية ولا تربط الأجهزة ببعضها.

بناء APK:
1) ارفع محتويات هذا المجلد إلى مستودع GitHub جديد، مع الحفاظ على المجلدات.
2) افتح تبويب Actions في المستودع.
3) اختر Build Android APK ثم Run workflow.
4) بعد نجاح البناء افتح صفحة التشغيل (workflow run) ونزّل Artifact باسم SHALLET-GAMERS-APK.
5) فك ضغط الملف الناتج لتحصل على app-debug.apk.

يتطلب إصداراً لاحقاً إضافة السيرفر الحقيقي وربط Socket.IO قبل أن تعمل الغرف بين الأجهزة.
